<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('css/style.css')); ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" type="text/css" rel="stylesheet">
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" type="text/css" rel="stylesheet">
</head>

<body>
<?php echo $__env->make('topnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>