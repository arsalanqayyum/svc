<?php $__env->startSection('content'); ?>
    <div class="prodcrumb"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <ul class="list-group">
                    <li class="breadcrumb list-group-item"><h4>by category</h4></li>
                    <?php foreach($sidecats as $cats): ?>
                        <li class="list-group-item">
                            <a  href="<?php echo e(url('products',[$cats->cats])); ?>"> <?php echo e($cats->cats); ?></a><span class="badge"><?php echo e($cats->counter); ?></span>
                        </li>
                    <?php endforeach; ?>
                    <li class="breadcrumb list-group-item"><h4>by products</h4></li>
                    <?php foreach($prodcat as $cats): ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(url('prodcat',[$cats->prod_cat])); ?>"><?php echo e($cats->prod_cat); ?></a><span class="badge"><?php echo e($cats->counter); ?></span>
                        </li>
                        <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-sm-9">
                <div class="breadcrumb">
                    <h4><?php echo e($cat); ?></h4>
                </div>
            <?php foreach($getcat as $posts): ?>
                <div class="col-sm-4">
                    <div class="new-items bottom">
                        <img src="<?php echo e(asset('uploads/images').'/'.$posts->image); ?>" class="img-responsive" width="100%"/>
                        <div class="overlay">
                            <div class="text"><?php echo e($posts->sub_title); ?></div>
                            <a href="<?php echo e(url('',[$posts->id])); ?>">view details</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>