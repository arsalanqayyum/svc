<?php $__env->startSection('content'); ?>

    <div id="myCarousel" class="carousel slider slide" data-ride="carousel">
        <!-- Indicators -->
        <?php /*<ol class="carousel-indicators">
            <?php foreach($sliders as $key => $slide): ?>
                <li data-target="#myCarousel" data-slide-to="<?php echo e($slide->index); ?>" class="<?php echo e($key == 0 ? ' active' : ''); ?>"></li>
            <?php endforeach; ?>
        </ol>*/ ?>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <?php foreach($sliders as $key => $slide): ?>
                <div class="item<?php echo e($key == 0 ? ' active' : ''); ?>">
                    <img src="<?php echo e(asset('uploads/slider').'/'.$slide->images); ?>" width="100%">
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

<div class="big-bg">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1><span><?php echo e($widget->pluck('title')[0]); ?> <i class="fa fa-tags"></i></span></h1>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <?php foreach($newitems as $posts): ?>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="new-items">
                    <img src="<?php echo e(asset('uploads/images').'/'.$posts->image); ?>" class="img-responsive"/>
                    <div class="overlay">
                        <div class="text"><?php echo e($posts->sub_title); ?></div>
                        <a href="<?php echo e(url('',[$posts->id])); ?>">view details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="viewall">
                <a href="<?php echo e(url('products',[$posts->cats])); ?>">view all</a>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1><span><?php echo e($widget->pluck('title')[1]); ?><i class="fa fa-lightbulb-o"></i></span></h1>
            </div>
        </div>
    </div>


    <div class="container-fluid">
        <div class="row">
            <?php foreach($scndsec as $post): ?>
            <div class="col-sm-12">
                <div class="align">
                    <img src="<?php echo e(asset('uploads/images').'/'.$post->image); ?>" class="img-responsive"/>
                    <div class="blur-overlay">
                        <a href="<?php echo e(url('',[$post->id])); ?>">read more</a>
                    </div>
                </div>

            </div>
                <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="bg-img">
    <div class="pattern">
    </div>
    <h1 class="bg-head"><?php echo e($widget->pluck('title')[2]); ?></h1>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="bg-layer">
                    <i class="fa fa-3x fa-thumbs-o-up"></i>
                </div>
                <div>
                    <h3 class="head"><?php echo e($widget->pluck('head')[3]); ?></h3>
                    <p class="paragragh"><?php echo e($widget->pluck('content')[3]); ?></p>
                </div>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="bg-layer">
                    <i class="fa fa-3x fa-star"></i>
                </div>
                <div>
                    <h3 class="head"><?php echo e($widget->pluck('head')[4]); ?></h3>
                    <p class="paragragh"><?php echo e($widget->pluck('content')[4]); ?></p>
                </div>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="bg-layer">
                    <i class="fa fa-3x fa-shopping-bag"></i>
                </div>
                <div>
                    <h3 class="head"><?php echo e($widget->pluck('head')[5]); ?></h3>
                    <p class="paragragh"><?php echo e($widget->pluck('content')[5]); ?></p>
                </div>
            </div>


        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h1><span><?php echo e($widget->pluck('title')[6]); ?></span></h1>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <ul class="list-inline brands">
                <?php foreach($brands as $brand): ?>
                <li><img src="<?php echo e(asset('uploads/brands').'/'.$brand->images); ?>" class="img-responsive"/></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>