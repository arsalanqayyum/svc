<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="{{asset('css/style.css')}}" type="text/css" rel="stylesheet">
    <link href="{{asset('css/bootstrap.css')}}" type="text/css" rel="stylesheet">
    <link href="{{asset('css/font-awesome.css')}}" type="text/css" rel="stylesheet">
</head>

<body>
@include('topnav')

@yield('content')

@include('footer')
</body>
    <script src="{{asset('js/googleapi.js')}}" type="text/javascript"></script>
<script src="{{asset('js/bootstrap.js')}}" type="text/javascript"></script>

</html>