<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class topnav extends Model
{
    protected $table = 'topnavs';
}
