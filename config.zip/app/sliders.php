<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sliders extends Model
{
    protected $table = 'sliders';
}
